
import React, { useState, useEffect, useCallback } from 'react';
import { View, UserProfile, DiagnosticAnalysis, AuditLog } from './types';
import { Icons, COLORS } from './constants';
import Dashboard from './components/Dashboard';
import Login from './components/Login';
import PatientRecords from './components/PatientRecords';
import AuditHistory from './components/AuditHistory';
import Profile from './components/Profile';
import RecordDetail from './components/RecordDetail';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [user, setUser] = useState<UserProfile | null>(null);
  const [patients, setPatients] = useState<DiagnosticAnalysis[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [selectedRecordId, setSelectedRecordId] = useState<string | null>(null);

  // Persistence
  useEffect(() => {
    const savedUser = localStorage.getItem('clara_user');
    const savedAuth = localStorage.getItem('clara_auth');
    const savedPatients = localStorage.getItem('clara_patients');
    const savedLogs = localStorage.getItem('clara_logs');

    if (savedUser && savedAuth === 'true') {
      setUser(JSON.parse(savedUser));
      setIsAuthenticated(true);
    }
    if (savedPatients) setPatients(JSON.parse(savedPatients));
    if (savedLogs) setAuditLogs(JSON.parse(savedLogs));
  }, []);

  const addAuditLog = useCallback((action: string, details: string) => {
    const newLog: AuditLog = {
      id: Math.random().toString(36).substr(2, 9),
      action,
      timestamp: new Date().toISOString(),
      details
    };
    const updatedLogs = [newLog, ...auditLogs].slice(0, 100);
    setAuditLogs(updatedLogs);
    localStorage.setItem('clara_logs', JSON.stringify(updatedLogs));
  }, [auditLogs]);

  const handleLogin = (profile: UserProfile) => {
    setUser(profile);
    setIsAuthenticated(true);
    localStorage.setItem('clara_user', JSON.stringify(profile));
    localStorage.setItem('clara_auth', 'true');
    addAuditLog('Login', `User ${profile.name} logged in`);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
    localStorage.removeItem('clara_auth');
    localStorage.removeItem('clara_user');
  };

  const handleAddPatient = (record: DiagnosticAnalysis) => {
    const updated = [record, ...patients];
    setPatients(updated);
    localStorage.setItem('clara_patients', JSON.stringify(updated));
    addAuditLog('New Analysis', `Diagnostic reasoning generated for ${record.patientName}`);
  };

  const navigateToRecord = (id: string) => {
    setSelectedRecordId(id);
    setCurrentView('record-detail');
  };

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard user={user!} onAnalysisComplete={handleAddPatient} />;
      case 'records':
        return <PatientRecords patients={patients} onSelectRecord={navigateToRecord} />;
      case 'record-detail':
        const record = patients.find(p => p.id === selectedRecordId);
        return record ? <RecordDetail analysis={record} user={user!} onBack={() => setCurrentView('records')} /> : null;
      case 'history':
        return <AuditHistory logs={auditLogs} />;
      case 'profile':
        return <Profile user={user!} onUpdate={(u) => {
          setUser(u);
          localStorage.setItem('clara_user', JSON.stringify(u));
          addAuditLog('Profile Update', 'User profile information updated');
        }} />;
      case 'settings':
        return (
          <div className="p-8">
            <h1 className="text-2xl font-bold mb-6">Settings</h1>
            <div className="bg-white p-6 rounded-xl border shadow-sm">
              <p className="text-gray-600">Clinical safety parameters and API configurations are managed by the hospital administrator.</p>
            </div>
          </div>
        );
      default:
        return <Dashboard user={user!} onAnalysisComplete={handleAddPatient} />;
    }
  };

  return (
    <div className="flex h-screen bg-white">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-50 border-r flex flex-col">
        <div className="p-6 flex items-center gap-3">
          <Icons.Stethoscope className="w-8 h-8 text-[#1976D2]" />
          <span className="text-2xl font-bold tracking-tight text-gray-900">CLARA</span>
        </div>
        
        <nav className="flex-1 px-4 space-y-2 mt-4">
          <SidebarItem 
            icon={<Icons.Dashboard className="w-5 h-5" />} 
            label="Dashboard" 
            active={currentView === 'dashboard'} 
            onClick={() => setCurrentView('dashboard')} 
          />
          <SidebarItem 
            icon={<Icons.Records className="w-5 h-5" />} 
            label="Patient Records" 
            active={currentView === 'records' || currentView === 'record-detail'} 
            onClick={() => setCurrentView('records')} 
          />
          <SidebarItem 
            icon={<Icons.History className="w-5 h-5" />} 
            label="Audit History" 
            active={currentView === 'history'} 
            onClick={() => setCurrentView('history')} 
          />
          <SidebarItem 
            icon={<Icons.Settings className="w-5 h-5" />} 
            label="Settings" 
            active={currentView === 'settings'} 
            onClick={() => setCurrentView('settings')} 
          />
        </nav>

        <div className="p-4 border-t space-y-2">
          <SidebarItem 
            icon={<Icons.User className="w-5 h-5" />} 
            label="Profile" 
            active={currentView === 'profile'} 
            onClick={() => setCurrentView('profile')} 
          />
          <button 
            onClick={handleLogout}
            className="flex items-center gap-3 w-full px-4 py-2 text-sm font-medium text-red-500 hover:bg-red-50 rounded-lg transition-colors"
          >
            <Icons.Logout className="w-5 h-5" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-white custom-scrollbar">
        {renderContent()}
      </main>
    </div>
  );
};

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`flex items-center gap-3 w-full px-4 py-2 text-sm font-medium rounded-lg transition-all ${
      active 
        ? 'bg-[#1976D2] text-white shadow-md' 
        : 'text-gray-600 hover:bg-gray-100'
    }`}
  >
    {icon}
    {label}
  </button>
);

export default App;
