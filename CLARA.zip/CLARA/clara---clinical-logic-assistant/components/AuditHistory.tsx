
import React from 'react';
import { AuditLog } from '../types';
import { Icons } from '../constants';

interface AuditHistoryProps {
  logs: AuditLog[];
}

const AuditHistory: React.FC<AuditHistoryProps> = ({ logs }) => {
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold">Audit History</h1>
        <p className="text-gray-500">Continuous monitoring of system interactions for clinical compliance</p>
      </div>

      <div className="space-y-4">
        {logs.length > 0 ? logs.map((log) => (
          <div key={log.id} className="bg-white p-6 rounded-2xl border shadow-sm flex items-start gap-6 hover:shadow-md transition-shadow">
            <div className="p-3 bg-gray-50 rounded-xl">
              <Icons.History className="w-6 h-6 text-gray-400" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <h3 className="font-bold text-gray-900">{log.action}</h3>
                <span className="text-xs text-gray-400 font-medium">{new Date(log.timestamp).toLocaleString()}</span>
              </div>
              <p className="text-sm text-gray-500">{log.details}</p>
            </div>
          </div>
        )) : (
          <div className="text-center py-20 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
            <p className="text-gray-400">No activity logs recorded yet.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AuditHistory;
