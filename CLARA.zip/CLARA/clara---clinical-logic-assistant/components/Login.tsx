
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Icons, COLORS } from '../constants';

interface LoginProps {
  onLogin: (profile: UserProfile) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [dept, setDept] = useState('Radiology');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;
    onLogin({
      name,
      department: dept,
      email: `${name.toLowerCase().replace(' ', '.')}@clara-health.io`,
      profilePic: `https://picsum.photos/seed/${name}/200`
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl p-8 border">
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-[#1976D2] rounded-2xl flex items-center justify-center mb-4 shadow-lg">
            <Icons.Stethoscope className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">CLARA</h1>
          <p className="text-gray-500 text-sm mt-1">Clinical Logic Assistant</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Full Name</label>
            <input 
              required
              type="text" 
              placeholder="Dr. Jane Doe"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#1976D2] outline-none transition-all"
            />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Department</label>
            <select 
              value={dept}
              onChange={(e) => setDept(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#1976D2] outline-none transition-all"
            >
              <option>Radiology</option>
              <option>Cardiology</option>
              <option>Neurology</option>
              <option>General Medicine</option>
              <option>Emergency</option>
            </select>
          </div>

          <button 
            type="submit"
            className="w-full py-4 bg-[#1976D2] text-white font-bold rounded-xl shadow-lg hover:bg-blue-700 transition-all active:scale-[0.98]"
          >
            Access Clinical Dashboard
          </button>
        </form>

        <p className="mt-8 text-center text-xs text-gray-400">
          This is a clinical tool. Your data is processed securely using HIPAA-compliant reasoning frameworks.
        </p>
      </div>
    </div>
  );
};

export default Login;
