
export enum Severity {
  HIGH = 'high',
  MEDIUM = 'medium',
  LOW = 'low'
}

export interface RiskFlag {
  id: string;
  title: string;
  detail: string;
  severity: Severity;
}

export interface DiagnosticAnalysis {
  id: string;
  timestamp: string;
  patientName: string;
  patientId: string;
  notes: string;
  filePreview?: string;
  confidence: number;
  reasoningSteps: string[];
  riskFlags: RiskFlag[];
  riskCategories: { name: string; value: number }[];
  summary: string;
}

export interface UserProfile {
  name: string;
  email: string;
  department: string;
  profilePic: string;
}

export interface AuditLog {
  id: string;
  action: string;
  timestamp: string;
  details: string;
}

export type View = 'dashboard' | 'records' | 'history' | 'settings' | 'profile' | 'record-detail';
