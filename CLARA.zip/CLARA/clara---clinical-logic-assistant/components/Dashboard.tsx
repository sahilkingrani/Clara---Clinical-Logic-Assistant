
import React, { useState } from 'react';
import { UserProfile, DiagnosticAnalysis, Severity } from '../types';
import { Icons, COLORS } from '../constants';
import { analyzeDiagnosticShadowing } from '../services/geminiService';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';

interface DashboardProps {
  user: UserProfile;
  onAnalysisComplete: (analysis: DiagnosticAnalysis) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, onAnalysisComplete }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [patientName, setPatientName] = useState('');
  const [notes, setNotes] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | undefined>();
  const [result, setResult] = useState<DiagnosticAnalysis | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      setFile(f);
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result as string);
      reader.readAsDataURL(f);
    }
  };

  const handleAnalyze = async () => {
    if (!patientName || !notes) return;
    setIsAnalyzing(true);
    try {
      const aiResponse = await analyzeDiagnosticShadowing(patientName, notes, preview);
      const analysis: DiagnosticAnalysis = {
        ...aiResponse,
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date().toISOString(),
        patientName,
        patientId: `PAT-${Math.floor(Math.random() * 9000) + 1000}`,
        notes,
        filePreview: preview
      };
      setResult(analysis);
      onAnalysisComplete(analysis);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const reset = () => {
    setResult(null);
    setPatientName('');
    setNotes('');
    setFile(null);
    setPreview(undefined);
  };

  const COLORS_CHART = ['#1976D2', '#26A69A', '#FFA000', '#EF5350'];

  return (
    <div className="p-8 max-w-7xl mx-auto animate-in fade-in duration-500">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Welcome, Dr. {user.name}</h1>
        <p className="text-gray-500">System status: All logic guards active | {user.department}</p>
      </header>

      {!result ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Inputs Section */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white p-6 rounded-2xl border shadow-sm space-y-4">
              <h2 className="text-lg font-bold flex items-center gap-2">
                <Icons.Alert className="w-5 h-5 text-blue-600" />
                Case Upload
              </h2>
              
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Patient Name</label>
                <input 
                  type="text"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="e.g. Michael Chen"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 focus:bg-white outline-none transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Clinical Notes & Symptoms</label>
                <textarea 
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={6}
                  placeholder="Describe patient history, primary symptoms, and any existing diagnoses to scan for shadowing..."
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 focus:bg-white outline-none transition-all resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Multimodal Input (X-rays, PDFs)</label>
                <label className="border-2 border-dashed border-gray-300 rounded-2xl p-8 flex flex-col items-center justify-center cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-all">
                  <input type="file" className="hidden" onChange={handleFileChange} />
                  <Icons.Upload className="w-10 h-10 text-gray-400 mb-2" />
                  <p className="text-sm text-gray-500">{file ? file.name : 'Drag & drop or click to upload'}</p>
                </label>
              </div>

              <button 
                disabled={isAnalyzing || !patientName || !notes}
                onClick={handleAnalyze}
                className={`w-full py-4 rounded-xl font-bold text-white shadow-lg transition-all flex items-center justify-center gap-3 ${
                  isAnalyzing ? 'bg-gray-400 cursor-not-allowed' : 'bg-[#1976D2] hover:bg-blue-700 active:scale-[0.99]'
                }`}
              >
                {isAnalyzing ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Synthesizing Logic Guard...
                  </>
                ) : (
                  <>
                    <Icons.Dashboard className="w-5 h-5" />
                    Deep Think Analysis
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick Stats Sidebar */}
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-[#1976D2] to-[#1565C0] p-6 rounded-2xl text-white shadow-lg">
              <h3 className="font-bold mb-2">Diagnostic Shadowing?</h3>
              <p className="text-sm opacity-90 leading-relaxed">
                Our high-reasoning Gemini 3 models analyze pattern inconsistencies that human clinicians might overlook due to "anchoring bias."
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-2xl border shadow-sm">
              <h3 className="font-bold mb-4">Risk Monitoring</h3>
              <div className="space-y-4">
                <RiskMiniCard label="Demographic Bias" value="Low" color="bg-green-500" />
                <RiskMiniCard label="Pattern Conflict" value="Med" color="bg-orange-500" />
                <RiskMiniCard label="Incomplete History" value="High" color="bg-red-500" />
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-8 pb-12">
          <div className="flex items-center justify-between">
            <button onClick={reset} className="text-[#1976D2] hover:underline font-medium">← New Analysis</button>
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-bold uppercase tracking-wider">Analysis Complete</span>
              <span className="text-gray-400 text-sm">{new Date(result.timestamp).toLocaleTimeString()}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Logic Guard Panel */}
            <div className="bg-white p-8 rounded-2xl border shadow-sm">
              <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
                  <Icons.Dashboard className="w-5 h-5 text-white" />
                </div>
                Diagnostic Reasoning Path
              </h2>
              <div className="space-y-6 relative">
                <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-100" />
                {result.reasoningSteps.map((step, idx) => (
                  <div key={idx} className="relative pl-10">
                    <div className="absolute left-2.5 top-1 w-3 h-3 rounded-full bg-blue-500 border-2 border-white shadow-sm" />
                    <p className="text-gray-700 leading-relaxed text-sm font-medium">{step}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Analytics Panel */}
            <div className="space-y-8">
              <div className="bg-white p-8 rounded-2xl border shadow-sm">
                <h2 className="text-xl font-bold mb-6">Clinical Insights</h2>
                <div className="grid grid-cols-2 gap-4">
                  <div className="h-48">
                    <h3 className="text-xs font-bold text-gray-400 uppercase text-center mb-2">AI Confidence</h3>
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={[{ value: result.confidence }, { value: 100 - result.confidence }]}
                          innerRadius={50}
                          outerRadius={70}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          <Cell fill="#1976D2" />
                          <Cell fill="#f3f4f6" />
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                    <p className="text-center font-bold text-2xl text-[#1976D2] mt-[-60px]">{result.confidence}%</p>
                  </div>
                  <div className="h-48">
                    <h3 className="text-xs font-bold text-gray-400 uppercase text-center mb-2">Risk Distribution</h3>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={result.riskCategories}>
                        <XAxis dataKey="name" hide />
                        <YAxis hide />
                        <Tooltip />
                        <Bar dataKey="value">
                          {result.riskCategories.map((_, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS_CHART[index % COLORS_CHART.length]} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-2xl border shadow-sm">
                <h2 className="text-lg font-bold mb-4">Risk Flags</h2>
                <div className="space-y-3">
                  {result.riskFlags.map((flag) => (
                    <div key={flag.id} className={`p-4 rounded-xl border-l-4 ${
                      flag.severity === Severity.HIGH ? 'bg-red-50 border-red-500' : 
                      flag.severity === Severity.MEDIUM ? 'bg-orange-50 border-orange-500' : 'bg-teal-50 border-teal-500'
                    }`}>
                      <h4 className="font-bold text-sm text-gray-900">{flag.title}</h4>
                      <p className="text-xs text-gray-600 mt-1">{flag.detail}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const RiskMiniCard = ({ label, value, color }: { label: string, value: string, color: string }) => (
  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
    <span className="text-sm text-gray-600 font-medium">{label}</span>
    <div className="flex items-center gap-2">
      <span className="text-xs font-bold text-gray-900">{value}</span>
      <div className={`w-2 h-2 rounded-full ${color}`} />
    </div>
  </div>
);

export default Dashboard;
