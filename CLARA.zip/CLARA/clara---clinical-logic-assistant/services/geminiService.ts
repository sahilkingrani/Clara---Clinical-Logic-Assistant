
import { GoogleGenAI, Type } from "@google/genai";
import { Severity } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeDiagnosticShadowing(
  patientName: string,
  medicalNotes: string,
  imageData?: string
) {
  const model = "gemini-3-pro-preview";
  
  const systemInstruction = `
    You are CLARA (Clinical Logic Assistant), a senior medical logic expert. 
    Your specialty is detecting "diagnostic shadowing" - where clinicians overlook serious new symptoms 
    because they attribute them to a patient's existing chronic condition or psychiatric history.
    
    Tasks:
    1. Analyze the provided clinical notes and image (if any).
    2. Identify step-by-step reasoning that could lead to a missed diagnosis.
    3. Generate color-coded risk flags (high, medium, low).
    4. Provide categorical risks: Demographic Bias, Incomplete History, Pattern Conflict, or Anchoring Bias.
    5. Be professional, clinical, and precise.
  `;

  const prompt = `
    Patient: ${patientName}
    Notes: ${medicalNotes}
    Please perform a Logic Guard deep-think analysis on this case.
  `;

  const parts: any[] = [{ text: prompt }];
  if (imageData) {
    parts.push({
      inlineData: {
        data: imageData.split(',')[1],
        mimeType: "image/png"
      }
    });
  }

  const response = await ai.models.generateContent({
    model,
    contents: { parts },
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      thinkingConfig: { thinkingBudget: 4000 },
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          confidence: { type: Type.NUMBER },
          reasoningSteps: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          riskFlags: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                detail: { type: Type.STRING },
                severity: { type: Type.STRING, enum: [Severity.HIGH, Severity.MEDIUM, Severity.LOW] }
              },
              required: ["title", "detail", "severity"]
            }
          },
          riskCategories: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                value: { type: Type.NUMBER }
              },
              required: ["name", "value"]
            }
          }
        },
        required: ["summary", "confidence", "reasoningSteps", "riskFlags", "riskCategories"]
      }
    }
  });

  return JSON.parse(response.text);
}
