
import React, { useState } from 'react';
import { DiagnosticAnalysis } from '../types';
import { Icons } from '../constants';

interface PatientRecordsProps {
  patients: DiagnosticAnalysis[];
  onSelectRecord: (id: string) => void;
}

const PatientRecords: React.FC<PatientRecordsProps> = ({ patients, onSelectRecord }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filtered = patients.filter(p => 
    p.patientName.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.patientId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold">Patient Records</h1>
          <p className="text-gray-500">History of all clinical deep-think scans</p>
        </div>
        <div className="relative">
          <input 
            type="text" 
            placeholder="Search by name or ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 border rounded-xl outline-none focus:ring-2 focus:ring-blue-500 w-full md:w-64"
          />
          <Icons.Dashboard className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
        </div>
      </div>

      <div className="bg-white border rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Patient</th>
              <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Timestamp</th>
              <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Confidence</th>
              <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Risk Level</th>
              <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {filtered.length > 0 ? filtered.map((p) => {
              const hasHighRisk = p.riskFlags.some(f => f.severity === 'high');
              return (
                <tr key={p.id} className="hover:bg-gray-50 transition-colors cursor-pointer" onClick={() => onSelectRecord(p.id)}>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">
                        {p.patientName.charAt(0)}
                      </div>
                      <div>
                        <div className="font-bold text-gray-900">{p.patientName}</div>
                        <div className="text-xs text-gray-400">{p.patientId}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    {new Date(p.timestamp).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500" style={{ width: `${p.confidence}%` }} />
                      </div>
                      <span className="text-xs font-bold text-blue-600">{p.confidence}%</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      hasHighRisk ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
                    }`}>
                      {hasHighRisk ? 'Critical Flags' : 'Normal'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button className="text-blue-600 hover:text-blue-800 font-semibold text-sm">View Analysis</button>
                  </td>
                </tr>
              );
            }) : (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-gray-400">
                  No patient records found. Start an analysis from the dashboard.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PatientRecords;
