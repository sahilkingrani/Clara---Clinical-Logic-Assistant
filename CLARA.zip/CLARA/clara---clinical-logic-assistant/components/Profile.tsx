
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Icons } from '../constants';

interface ProfileProps {
  user: UserProfile;
  onUpdate: (updated: UserProfile) => void;
}

const Profile: React.FC<ProfileProps> = ({ user, onUpdate }) => {
  const [name, setName] = useState(user.name);
  const [dept, setDept] = useState(user.department);
  const [email, setEmail] = useState(user.email);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    onUpdate({ ...user, name, department: dept, email });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div className="p-8 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-8">Practitioner Profile</h1>

      <div className="bg-white p-8 rounded-2xl border shadow-sm space-y-8">
        <div className="flex items-center gap-6 pb-8 border-b">
          <img src={user.profilePic} alt="avatar" className="w-24 h-24 rounded-2xl object-cover border-4 border-white shadow-lg" />
          <div>
            <h2 className="text-xl font-bold">{user.name}</h2>
            <p className="text-gray-500 text-sm">Practitioner License: CLARA-99221-A</p>
            <button className="text-blue-600 text-xs font-bold mt-2 uppercase tracking-wider hover:underline">Change Profile Image</button>
          </div>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Display Name</label>
              <input 
                type="text" 
                value={name} 
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-2 border rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Department</label>
              <select 
                value={dept} 
                onChange={(e) => setDept(e.target.value)}
                className="w-full px-4 py-2 border rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option>Radiology</option>
                <option>Cardiology</option>
                <option>Neurology</option>
                <option>General Medicine</option>
                <option>Emergency</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Email Address</label>
            <input 
              type="email" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2 border rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-4 pt-4">
          <button 
            onClick={handleSave}
            className="px-8 py-3 bg-[#1976D2] text-white font-bold rounded-xl shadow-lg hover:bg-blue-700 transition-all active:scale-[0.98]"
          >
            Save Changes
          </button>
          {isSaved && <span className="text-green-600 text-sm font-bold animate-in fade-in slide-in-from-left-2">✓ Profile Updated Successfully</span>}
        </div>
      </div>

      <div className="mt-8 p-6 bg-red-50 border border-red-100 rounded-2xl flex items-center justify-between">
        <div>
          <h4 className="text-red-700 font-bold text-sm">Danger Zone</h4>
          <p className="text-red-600/70 text-xs">Deleting your profile will wipe all patient analytics and audit logs permanently.</p>
        </div>
        <button className="text-red-700 text-xs font-bold border border-red-200 px-4 py-2 rounded-lg hover:bg-red-100 transition-colors">Delete Account</button>
      </div>
    </div>
  );
};

export default Profile;
