
import { jsPDF } from "jspdf";
import { DiagnosticAnalysis, UserProfile } from "../types";

export function generateAuditPDF(analysis: DiagnosticAnalysis, user: UserProfile) {
  const doc = new jsPDF();
  const primaryColor = "#1976D2";

  // Branding
  doc.setFillColor(primaryColor);
  doc.rect(0, 0, 210, 25, 'F');
  doc.setTextColor("#FFFFFF");
  doc.setFontSize(22);
  doc.text("CLARA | Clinical Audit Report", 15, 17);
  
  doc.setTextColor("#666666");
  doc.setFontSize(10);
  doc.text(`Generated on: ${new Date().toLocaleString()}`, 145, 17);

  // User/Doctor info
  doc.setTextColor("#000000");
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.text("Clinical Information", 15, 40);
  doc.setFont("helvetica", "normal");
  doc.text(`Practitioner: Dr. ${user.name}`, 15, 48);
  doc.text(`Department: ${user.department}`, 15, 54);
  doc.text(`Patient Reference: ${analysis.patientName} (ID: ${analysis.patientId})`, 15, 60);

  // Confidence Score
  doc.setFillColor(primaryColor);
  doc.rect(150, 40, 45, 20, 'F');
  doc.setTextColor("#FFFFFF");
  doc.setFontSize(10);
  doc.text("AI CONFIDENCE", 155, 47);
  doc.setFontSize(16);
  doc.text(`${analysis.confidence}%`, 155, 55);

  // Logic Guard Reasoning
  doc.setTextColor("#000000");
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.text("Logic Guard: Diagnostic Reasoning Path", 15, 75);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  
  let yPos = 85;
  analysis.reasoningSteps.forEach((step, index) => {
    const lines = doc.splitTextToSize(`${index + 1}. ${step}`, 180);
    doc.text(lines, 15, yPos);
    yPos += (lines.length * 5) + 3;
  });

  // Risk Flags
  yPos += 5;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.text("Clinical Risk Flags", 15, yPos);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  yPos += 8;

  analysis.riskFlags.forEach(flag => {
    if (yPos > 270) {
      doc.addPage();
      yPos = 20;
    }
    const color = flag.severity === 'high' ? "#EF5350" : flag.severity === 'medium' ? "#FFA000" : "#26A69A";
    doc.setTextColor(color);
    doc.text(`[${flag.severity.toUpperCase()}] ${flag.title}`, 15, yPos);
    doc.setTextColor("#333333");
    const lines = doc.splitTextToSize(flag.detail, 170);
    doc.text(lines, 20, yPos + 5);
    yPos += (lines.length * 5) + 10;
  });

  // Summary
  if (yPos > 250) {
    doc.addPage();
    yPos = 20;
  }
  doc.setFont("helvetica", "bold");
  doc.text("Clinical Audit Summary", 15, yPos);
  doc.setFont("helvetica", "normal");
  const summaryLines = doc.splitTextToSize(analysis.summary, 180);
  doc.text(summaryLines, 15, yPos + 7);

  doc.save(`Clinical_Audit_${analysis.patientId}_${Date.now()}.pdf`);
}
