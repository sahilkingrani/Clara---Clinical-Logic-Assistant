
import React from 'react';
import { DiagnosticAnalysis, UserProfile } from '../types';
import { Icons } from '../constants';
import { generateAuditPDF } from '../services/pdfService';

interface RecordDetailProps {
  analysis: DiagnosticAnalysis;
  user: UserProfile;
  onBack: () => void;
}

const RecordDetail: React.FC<RecordDetailProps> = ({ analysis, user, onBack }) => {
  return (
    <div className="p-8 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-500 hover:text-gray-900 transition-colors">
          <Icons.Dashboard className="w-4 h-4 rotate-180" />
          Back to Records
        </button>
        <button 
          onClick={() => generateAuditPDF(analysis, user)}
          className="bg-[#1976D2] text-white px-6 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-blue-700 transition-all shadow-md active:scale-[0.98]"
        >
          <Icons.Upload className="w-4 h-4" />
          Download Clinical Audit
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-8 rounded-2xl border shadow-sm">
            <h1 className="text-2xl font-bold mb-2">{analysis.patientName}</h1>
            <p className="text-gray-400 text-sm mb-6">Patient ID: {analysis.patientId} | Scanned on: {new Date(analysis.timestamp).toLocaleString()}</p>
            
            <section className="mb-8">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Original Medical Notes</h3>
              <div className="p-4 bg-gray-50 rounded-xl text-sm leading-relaxed text-gray-600 italic">
                "{analysis.notes}"
              </div>
            </section>

            <section>
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Logic Guard Reasoning Path</h3>
              <div className="space-y-4">
                {analysis.reasoningSteps.map((step, idx) => (
                  <div key={idx} className="flex gap-4 p-4 rounded-xl bg-blue-50/30 border border-blue-100">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold">{idx + 1}</span>
                    <p className="text-gray-700 text-sm">{step}</p>
                  </div>
                ))}
              </div>
            </section>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border shadow-sm">
            <h3 className="font-bold mb-4">Diagnostic Integrity</h3>
            <div className="flex items-center justify-center p-6 bg-blue-50 rounded-2xl mb-4">
              <div className="text-center">
                <span className="text-4xl font-black text-blue-600">{analysis.confidence}%</span>
                <p className="text-xs text-blue-400 font-bold uppercase mt-1">AI Confidence</p>
              </div>
            </div>
            {analysis.filePreview && (
              <div className="rounded-xl overflow-hidden border">
                <p className="text-[10px] font-bold text-center bg-gray-100 py-1 text-gray-500">UPLOADED ATTACHMENT</p>
                <img src={analysis.filePreview} alt="attachment" className="w-full h-auto object-cover max-h-48" />
              </div>
            )}
          </div>

          <div className="bg-white p-6 rounded-2xl border shadow-sm">
            <h3 className="font-bold mb-4">Detected Clinical Risks</h3>
            <div className="space-y-3">
              {analysis.riskFlags.map((flag, idx) => (
                <div key={idx} className="p-4 rounded-xl border bg-gray-50">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-sm text-gray-900">{flag.title}</span>
                    <span className={`text-[9px] font-black px-1.5 py-0.5 rounded ${
                      flag.severity === 'high' ? 'bg-red-500 text-white' : 'bg-gray-200 text-gray-600'
                    }`}>{flag.severity.toUpperCase()}</span>
                  </div>
                  <p className="text-xs text-gray-500 leading-normal">{flag.detail}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecordDetail;
